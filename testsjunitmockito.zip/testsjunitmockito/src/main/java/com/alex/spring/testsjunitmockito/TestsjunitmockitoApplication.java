package com.alex.spring.testsjunitmockito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestsjunitmockitoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestsjunitmockitoApplication.class, args);
	}

}
